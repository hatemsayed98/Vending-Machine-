#include "counter.h"

 int get_counter(int x)
     {
          return(--amounts[x]);
     }
