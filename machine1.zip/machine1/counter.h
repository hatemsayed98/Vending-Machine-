#ifndef COUNTER_H
#define COUNTER_H


class counter
{
public:
     int get_counter(int x);
    protected:
         int amounts [10] = {10 , 10 ,10 , 10 , 10 , 10 , 10 , 10 , 10 , 10};
};

#endif // COUNTER_H
