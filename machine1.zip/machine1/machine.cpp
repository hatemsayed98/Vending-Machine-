/*
Assignment 3
Date   : 17 / 11 /2017
Name 1 : Eslam Saleh Ahmed
ID     : 20170045

Name 2 : Hatem Sayed Ali
ID     : 20170084

Vending Machine
*/
#include "machine.h"
#include<iostream>
using namespace std;
machine::machine(int x, double dollars)
{
                 /// items[x];

             ///  this->counter=get_counter;
             ///  amounts[x]=get_counter;
              /// cout<<get_counter<<endl;
                /// int get_xx();
                 int get_counter(x);

                int y=get_counter;
                  // cout<<y<<endl;
                 if(amounts[x]==0)
                 {
                      cout<<"Dont find this :";
                 }
                 else{


                    {
                            if (dollars > 1.25)
                            {
                                    cout << "You purchased: Coke\n";
                                    double coin=dollars-1.25;
                                    if(coin>=15){
                                    cout << "Your change is: $"<<"\n10"<<"\n5";

                                     int remind=coin-15;
                                     for(int i=0;i<remind;i++)
                                     {
                                          cout<<"\n1";
                                     }
                                     double reminder=(coin-15-remind);
                                     if(reminder==0.25)
                                        cout<<"\n0.25"<<endl;
                                       /// cout<<endl<<reminder<<endl;
                                    else
                                        cout<<"\n0.50"<<"\n0.25"<<endl;
                            }
                                    else if(coin>=10){
                                    cout << "Your change is: $"<<"\n10";

                                     int remind=coin-10;
                                     for(int i=0;i<remind;i++)
                                     {
                                          cout<<"\n1";
                                     }
                                     double reminder=(coin-10-remind);
                                     if(reminder==0.25)
                                        cout<<"\n0.25"<<endl;
                                       /// cout<<endl<<reminder<<endl;
                                    else
                                        cout<<"\n0.50"<<"\n0.25"<<endl;
                            }
                                   else  if(coin>=5){
                                    cout << "Your change is: $"<<"\n5";

                                     int remind=coin-5;
                                     for(int i=0;i<remind;i++)
                                     {
                                          cout<<"\n1";
                                     }
                                     double reminder=(coin-5-remind);
                                     if(reminder==0.25)
                                        cout<<"\n0.25"<<endl;
                                       /// cout<<endl<<reminder<<endl;
                                    else
                                        cout<<"\n0.50"<<"\n0.25"<<endl;
                            }
                                   else{
                                    cout << "Your change is: $";

                                     int remind=coin;
                                      for(int i=0;i<remind;i++)
                                     {
                                          cout<<"\n1";
                                     }
                                     double reminder=(coin-remind);
                                     if(reminder==0.25)
                                        cout<<"\n0.25"<<endl;
                                       /// cout<<endl<<reminder<<endl;
                                    else
                                        cout<<"\n0.50"<<"\n0.25"<<endl;
                            }

                            }
                            else
                            {
                                    cout << "You do not have enough money for this purchase. Goodbye!\n";
                            }
                    }
            }



}
int get_counter(int x)
{
     ///return(--amounts[x]);
}
machine::~machine()
{
     //dtor
}
