#ifndef MACHINE_H
#define MACHINE_H
#include<iostream>
using namespace std;
class machine
{
     public:
          machine(int x,double dollars);
          friend int get_counter(int x);
         /// virtual int get_xx();
          virtual ~machine();

     protected:

     private:
int amounts [10] = {2 , 2 ,10 , 10 , 10 , 10 , 10 , 10 , 10 , 10};
};


#endif // MACHINE_H
