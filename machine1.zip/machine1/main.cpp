#include <iostream>
#include"machine.h"
using namespace std;

int main()
{
    int choice;
    double dollars;
   int y;

    ///int amounts [10] = {10 , 10 ,10 , 10 , 10 , 10 , 10 , 10 , 10 , 10};
do{
    cout << "==============================================================\n";
    cout << "*                                                            *\n";
    cout << "*              VENDING MACHINE SIMULATOR                     *\n";
    cout << "*                                                            *\n";
    cout << "==============================================================\n";

    cout << "Your Choices Are:\n";
    cout << "1) Coke     - $1.25\n";
    cout << "2) Pepsi    - $2.25\n";
    cout << "3) Sprite   - $1.25\n";
    cout << "4) 7-up     - $1.15\n";
    cout << "5) Water    - $2.20\n";

    // Ask for user's selection.

    cout << "What would you like to purchase today?\n";
    cin >> choice;
    cout << "How many dollar bills will you use?\n";
    cin >> dollars;

 machine  ma(choice,dollars);

   /* switch (choice)
    {
            case 1:
            {
                 int x=-- amounts[0];
                 if(x==0)
                 {
                      cout<<"Dont find this :";
                 }
                 else{

                    cout << "How many dollar bills will you use?\n";
                    cin >> dollars;
                    {
                            if (dollars > 1.25)
                            {
                                    cout << "You purchased: Coke\n";
                                    double coin=dollars-1.25;
                                    if(coin>=15){
                                    cout << "Your change is: $"<<"\n10"<<"\n5";

                                     int remind=coin-15;
                                     for(int i=0;i<remind;i++)
                                     {
                                          cout<<"\n1";
                                     }
                                     double reminder=(coin-15-remind);
                                     if(reminder==0.25)
                                        cout<<"\n0.25"<<endl;
                                       /// cout<<endl<<reminder<<endl;
                                    else
                                        cout<<"\n0.50"<<"\n0.25"<<endl;
                            }
                                    else if(coin>=10){
                                    cout << "Your change is: $"<<"\n10";

                                     int remind=coin-10;
                                     for(int i=0;i<remind;i++)
                                     {
                                          cout<<"\n1";
                                     }
                                     double reminder=(coin-10-remind);
                                     if(reminder==0.25)
                                        cout<<"\n0.25"<<endl;
                                       /// cout<<endl<<reminder<<endl;
                                    else
                                        cout<<"\n0.50"<<"\n0.25"<<endl;
                            }
                                   else  if(coin>=5){
                                    cout << "Your change is: $"<<"\n5";

                                     int remind=coin-5;
                                     for(int i=0;i<remind;i++)
                                     {
                                          cout<<"\n1";
                                     }
                                     double reminder=(coin-5-remind);
                                     if(reminder==0.25)
                                        cout<<"\n0.25"<<endl;
                                       /// cout<<endl<<reminder<<endl;
                                    else
                                        cout<<"\n0.50"<<"\n0.25"<<endl;
                            }
                                   else{
                                    cout << "Your change is: $";

                                     int remind=coin;
                                      for(int i=0;i<remind;i++)
                                     {
                                          cout<<"\n1";
                                     }
                                     double reminder=(coin-remind);
                                     if(reminder==0.25)
                                        cout<<"\n0.25"<<endl;
                                       /// cout<<endl<<reminder<<endl;
                                    else
                                        cout<<"\n0.50"<<"\n0.25"<<endl;
                            }

                            }
                            else
                            {
                                    cout << "You do not have enough money for this purchase. Goodbye!\n";
                            }
                    }
            }}
                      break;
            case 2:
            {
                    cout << "How many dollar bills will you use?\n";
                    cin >> dollars;
                    {
                            if (dollars > 2.25)
                            {
                                    cout << "You purchased: Pepsi\n";
                                    cout << "Your change is: $"<< (dollars - 1.75);
                            }
                            else
                            {
                                    cout << "You do not have enough money for this purchase. Goodbye!\n";
                            }
                    }
            }
            case 3:
            {
                    cout << "How many dollar bills will you use?\n";
                    cin >> dollars;
                    {
                            if (dollars > 1.25)
                            {
                                    cout << "You purchased: Sprite\n";
                                    cout << "Your change is: $"<< (dollars - 1.25);
                            }
                            else
                            {
                                    cout << "You do not have enough money for this purchase. Goodbye!\n";
                            }
                    }
            }
                      break;
            case 4:
            {
                    cout << "How many dollar bills will you use?\n";
                    cin >> dollars;
                    {
                            if (dollars > 1.15)
                            {
                                    cout << "You purchased: 7-up\n";
                                    cout << "Your change is: $"<< (dollars - 1.15);
                            }
                            else
                            {
                                    cout << "You do not have enough money for this purchase. Goodbye!\n";
                            }
                    }
            }
                      break;
            case 5:
            {
                    cout << "How many dollar bills will you use?\n";
                    cin >> dollars;
                    {
                            if (dollars > 2.20)
                            {
                                    cout << "You purchased: Water\n";
                                    cout << "Your change is: $"<< (dollars - 2.20);
                            }
                            else
                            {
                                    cout << "You do not have enough money for this purchase. Goodbye!\n";
                            }
                    }
            }

                      break;
            default: cout << "Your choice is INVALID. Goodbye!\n";
     }*/
     cout<<"Enter"<<endl;
     cin>>y;
     }while(y==1);
    return 0;
}
